function like(add) {
    add.innerText++;
}