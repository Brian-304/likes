function heart(increase) {
    increase.innerText++;
    
}
